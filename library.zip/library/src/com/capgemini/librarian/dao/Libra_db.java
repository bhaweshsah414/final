package com.capgemini.librarian.dao;
import com.capgemini.exception.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.jar.*;

public class Libra_db {
	
	private static Connection con1;
	
	public static Connection getConnection() throws ClassNotFoundException,SQLException, FilenotfoundException
	{


	if(con1 == null)
	{
		try{
		 
		String jdbcdriver= "oracle.jdbc.driver.OracleDriver";
		Class.forName(jdbcdriver);
		String jdbcURL = "jdbc:oracle:thin:@localhost:1521:XE";
		String userName = "System";
		String password = "Capgemini123";
		
		con1 = DriverManager.getConnection(jdbcURL, userName, password);
		
		}

		catch(SQLException se)
		{
			throw new FilenotfoundException("table does not exist "+se.getMessage());
		
		}
		
		
		
	}
	return con1;
	}
	}

