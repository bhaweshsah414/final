package com.capgemini.servicelayer;

import java.sql.SQLException;



import com.capgemini.dto.Lib_dto;
import com.capgemini.exception.FilenotfoundException;
import com.capgemini.librarian_dto.Addview_book;
import com.capgemini.librarian_dto.Del_book;
import com.capgemini.librarian_dto.Reg_user;

public interface Lib_service {
 public int Insertissuedetails(Lib_dto dto) throws FilenotfoundException,SQLException,ClassNotFoundException;
 public void returnbook(Lib_dto del) throws FilenotfoundException,SQLException,ClassNotFoundException;
 public int Addview (Addview_book ad) throws FilenotfoundException,SQLException,ClassNotFoundException;
 public void Delete(Del_book db) throws FilenotfoundException,SQLException,ClassNotFoundException;
 public void Register(Reg_user ru) throws FilenotfoundException,SQLException,ClassNotFoundException;
	    
}
